# SSL Port Status Server

This folder contains a standalone Python server for your **server laptop**.

- Accepts multiple SSL/TLS client connections concurrently
- Scans requested TCP port ranges
- Returns how many ports are open (plus the open port list)
- Writes detailed connection logs to `server/logs/connections.log`

## Run on server laptop

From project root:

```bash
python3 server/ssl_port_status_server.py
```

Default bind: `0.0.0.0:9443`

The script auto-generates self-signed certs (if missing):

- `server/certs/server-cert.pem`
- `server/certs/server-key.pem`

## Request format (from clients)

Send one line JSON (newline-terminated):

```json
{"start_port":1,"end_port":1024,"target":"127.0.0.1"}
```

- `target` is optional (default: `127.0.0.1`)

## Response format

```json
{
  "ok": true,
  "request_id": "a1b2c3d4",
  "target": "127.0.0.1",
  "resolved_ip": "127.0.0.1",
  "start_port": 1,
  "end_port": 1024,
  "open_ports": 2,
  "total_scanned": 1024,
  "scan_duration_seconds": 0.734,
  "results": [{"port": 22, "status": "open"}]
}
```

On errors:

```json
{"ok":false,"request_id":"...","error":"..."}
```

## Quick test client (optional)

```bash
printf '{"start_port":1,"end_port":200}\n' | \
openssl s_client -connect 127.0.0.1:9443 -quiet -ign_eof
```
